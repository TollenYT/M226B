﻿using System;
using System.Collections.Generic;
using System.Text;

namespace M226HZ3._3
{
    class Animal
    {
        
    }
    
    class Dog : Animal
    {

    }

    class Cat : Animal
    {

    }
}
